# Guided Project Starter: Groceries

This is the starter project for the module _Swift Fundamenals I_ in the sprint _Introduction to iOS Programming_.

<img height="500px" src="Screen Shot 2019-07-10 at 9.36.54 AM.png">
